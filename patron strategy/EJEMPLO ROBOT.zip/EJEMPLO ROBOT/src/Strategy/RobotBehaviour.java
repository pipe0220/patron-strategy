package Strategy;

public interface RobotBehaviour {
    public int moveCommand();
    
}
